#差异分析
DE_selected<-function(edger,limma,deseq2,out,gene_set=FALSE,PD=1){
  #系统配置
  print("version: 1.0.0")
  print("author: 刘品博/Liu_Pinbo")
  print("e-Mail：liupinbo1999@163.com")
  print("packages：org.Hs.eg.db/clusterProfiler/tidyverse")
  Sys.sleep(2)
  print("Analysis of start")
  #读取差异分析结果
  edger<-read.table(file = edger,sep = "\t",header = T,row.names = 1,check.names = F)
  limma<-read.table(file = limma,sep = "\t",header = T,row.names = 1,check.names = F)
  deseq2<-read.table(file = deseq2,sep = "\t",header = T,row.names = 1,check.names = F)
  #提取上调或下调差异基因
  if(PD>0){
    print("选取上调基因")
    deseq2<-deseq2[deseq2$padj<0.05,]
    deseq2<-deseq2[deseq2$log2FoldChange>PD,]
    limma<-limma[limma$logFC>PD,]
    limma<-limma[limma$FDR<0.05,]
    edger<-edger[edger$FDR<0.05,]
    edger<-edger[edger$logFC>PD,]
  }else{
    print("选取下调基因")
    deseq2<-deseq2[deseq2$padj<0.05,]
    deseq2<-deseq2[deseq2$log2FoldChange<PD,]
    limma<-limma[limma$logFC<PD,]
    limma<-limma[limma$FDR<0.05,]
    edger<-edger[edger$FDR<0.05,]
    edger<-edger[edger$logFC<PD,]
  }
  #提取共有上/下调基因
  gene<-data.frame(gene=intersect(rownames(deseq2),rownames(edger)))
  gene<-data.frame(gene=intersect(gene$gene,rownames(limma)))
  #输出共有上/下调基因
  print("########正在输出上/下调基因########")
  out_dir=paste(out,"/共有基因(",PD,").txt",sep = "")
  write.table(x = gene,file = out_dir,sep = "\t",quote = F,row.names = F)
  print("########上/下调基因输出完毕########")
  print("输出Counts文件注意行列标签对齐")
  rm(deseq2,edger,limma)
  #与基因集取交集
  if(gene_set!=FALSE){
    DX_raw<-read.table(file = gene_set,sep = "\t",header = T,check.names = F)
    gene<-data.frame(gene=intersect(gene$gene,DX_raw$`Gene Symbol`))
  }else{
    print("未选定特定基因集")
  }
  return(gene)
}

edger="G:/湘雅/陆君5/02-差异分析/EdgeR/DE_data.txt.Normal_vs_Tumor.edgeR.DE_results"
limma="G:/湘雅/陆君5/02-差异分析/voom/DE_data.txt.Normal_vs_Tumor.voom.DE_results"
deseq2="G:/湘雅/陆君5/02-差异分析/DESeq2/DE_data.txt.Normal_vs_Tumor.DESeq2.DE_results"
out="G:/湘雅/陆君5/00-原始数据/temp2"
gene_set="G:/湘雅/陆君4/代谢基因.txt"
gene<-DE_selected(edger,limma,deseq2,out,PD = 1,gene_set = gene_set)

#######################################################################################
#合并临床信息和矩阵
merge_Countsandmeta<-function(Counts,clinical,out){
  #系统配置
  print("version: 1.0.0")
  print("author: 刘品博/Liu_Pinbo")
  print("e-Mail：liupinbo1999@163.com")
  print("packages：org.Hs.eg.db/clusterProfiler/tidyverse")
  Sys.sleep(2)
  print("Analysis of start")
  #所需要的包
  library(tidyverse)
  #读取Counts矩阵文件
  Counts<-read.table(file=Counts,sep = "\t",check.names = F,header = T,row.names = 1)
  #提取矩阵中癌样本数据
  Counts<-Counts[Counts$Sample.Type=="Tumor",]
  print(paste("剔除正常样本后样本剩余：",length(rownames(Counts)),sep = ""))
  #读取临床数据
  clinical<-read.table(file = clinical,sep = "\t",check.names = F,header = T)
  #提取临床数据中所需信息
  title<-c("case_submitter_id","vital_status","days_to_last_follow_up","days_to_death","age_at_index","gender","ajcc_pathologic_stage")
  clinical<-clinical[,title]
  #修改列标签
  colnames(clinical)<-c("sample_id","event","last_followup","days_to_death","age","gender","stage")
  #去除重复的样本信息
  clinical<-clinical[which(duplicated(clinical$sample_id)==FALSE),]
  #将event事件转化为数值：0为存活，1为死亡
  clinical$event<-ifelse(clinical$event=="Alive",0,1)
  #将生存时间和死亡时间中NA值转化为0
  clinical$last_followup[is.na(clinical$last_followup)]<-0
  clinical$days_to_death[is.na(clinical$days_to_death)]<-0
  #合并随访时间和死亡时间为生存时间
  b<-colnames(clinical)
  b<-b[-c(which(colnames(clinical)=="last_followup"),which(colnames(clinical)=="days_to_death"))]
  a<-ifelse(clinical$last_followup>clinical$days_to_death,clinical$last_followup,clinical$days_to_death)
  clinical<-cbind(clinical[,b],last_followup=a)
  rm(a,b,title)
  #gender/stage转化为因子
  clinical$gender<-as.factor(clinical$gender)
  clinical$stage<-as.factor(clinical$stage)
  #临床信息样本与矩阵样本数据取交集
  Counts<-Counts[Counts$Case.ID %in% clinical$sample_id,]
  clinical<-clinical[clinical$sample_id %in% Counts$Case.ID,]
  #去除矩阵中重复患者数据
  Counts<-Counts[which(duplicated(Counts$Case.ID)==FALSE),]
  #合并矩阵与临床信息数据
  data<-left_join(clinical,Counts,by=c("sample_id"="Case.ID"))
  #输出样本数
  print(paste("剔除没有临床信息和重复的患者样本，剩余样本：",length(rownames(data))))
  #删除样本类型变量
  data<-data[,-which(colnames(data)=="Sample.Type")]
  #将患者ID作为行标签
  rownames(data)<-data[,1]
  #删除患者ID变量
  data<-data[,-1]
  #重命名矩阵
  Counts<-data
  #删除变量
  rm(clinical,data)
  #筛选随访时间大于30的数据
  Counts<-Counts[Counts$last_followup>30,]
  #表达量取log2(x+1)
  Counts[,6:ncol(Counts)]<-log2(Counts[,6:ncol(Counts)]+1)
  #输出样本数量
  print(paste("随访时间大于30的样本数为：",length(rownames(Counts))))
  #输出文件
  print("########正在输出矩阵########")
  dir_out<-paste(out,"/Counts含临床数据.txt",sep="")
  write.table(Counts,file = dir_out,col.names = T,row.names = T,quote = F)
  print("########矩阵输出完毕########")
  print("输出Counts文件注意行列标签对齐")
  #返回Counts
  return(Counts)
}
Counts="G:/湘雅/陆君5/00-原始数据/temp2/Counts.txt"
#将临床信息文件中的'--替换为NA
clinical="G:/湘雅/陆君5/00-原始数据/clinical.tsv"
out="G:/湘雅/陆君5/00-原始数据/temp2"
Counts<-merge_Countsandmeta(Counts,clinical,out)

#######################################################################################
#单因素cox
simpleCox<-function(list2,SUR = data_frame()){
  #系统配置
  print("version: 1.0.0")
  print("author: 刘品博/Liu_Pinbo")
  print("e-Mail：liupinbo1999@163.com")
  print("packages：org.Hs.eg.db/clusterProfiler/tidyverse")
  Sys.sleep(2)
  print("Analysis of start")
  #包
  library(survival)
  library(survminer)
  library(tidyverse)
  #逐个基因单因素cox
  for (var2 in list2) {
    #合并变量公式
    s=as.formula(paste("Surv(last_followup, event) ~ ",var2,sep = ""))
    #单因素cox，矩阵名为Counts
    res.cox2 <- coxph(s,data = Counts)
    #提取单因素结果信息
    summary2<-summary(res.cox2)
    #提取p值，并保留4位数
    p.value2 <- signif(summary2$wald["pvalue"], digits=4)
    #提取风险值，并保留4位数
    HR2 <-signif(summary2$coef[2], digits=4)
    #提取风险区间下限，保留4位数
    HR2.confint.lower <- signif(summary2$conf.int[,"lower .95"],digits=4)
    #提取风险区间上限，保留4位数
    HR2.confint.upper <- signif(summary2$conf.int[,"upper .95"],digits=4)
    #合并风险区间
    HR3 <- paste0(HR2, "(", HR2.confint.lower, "~", HR2.confint.upper, ")")
    #合并单因素结果信息
    HR2 <- c(p.value2,HR3,HR2,HR2.confint.lower,HR2.confint.upper)
    #重命名向量标签
    names(HR2)<-c("p.value "," HR (95% lower for upper)","HR","95%lower","95%upper")
    #转化为data.frame格式
    temp2 <- as.data.frame(HR2,check.names =FALSE)
    #添加列标签
    colnames(temp2)<-var2
    #转置
    temp2 <- t(temp2)
    #行合并单因素单基因结果
    SUR<-rbind(SUR,temp2)
  }
  #输出结果
  return(SUR)
}
SimpleCox_result<-simpleCox(gene$gene)
SimpleCox_result<-SimpleCox_result[SimpleCox_result$`p.value `<=0.05,]
cox_gene<-rownames(SimpleCox_result)

#######################################################################################
#my.stepwish
stepwish<-function(cox_gene,Counts){
  #系统配置
  print("version: 1.0.0")
  print("author: 刘品博/Liu_Pinbo")
  print("e-Mail：liupinbo1999@163.com")
  print("packages：org.Hs.eg.db/clusterProfiler/tidyverse")
  Sys.sleep(2)
  print("Analysis of start")
  #包
  library(My.stepwise)
  #提取目标基因表达矩阵
  d<-Counts[,cox_gene]
  #提取生存时间和事件标签
  met2<-c("event","last_followup")
  #合并目标基因生存时间和事件以及表达矩阵
  dat2=cbind(Counts[met2],d)
  #最佳模型测试
  print(My.stepwise.coxph(Time = "last_followup",Status = "event",variable.list = cox_gene,data = dat2))
}
stepwish(cox_gene,Counts)
#手动输入gene_id
mutilgene<-c("ACSL1","HSD11B1","GSTT2","NT5E","ENPP6","LIPJ","COLGALT2")

#######################################################################################
#多因素cox
multiCox<-function(mutilgene,Counts,out){
  #系统配置
  print("version: 1.0.0")
  print("author: 刘品博/Liu_Pinbo")
  print("e-Mail：liupinbo1999@163.com")
  print("packages：org.Hs.eg.db/clusterProfiler/tidyverse")
  Sys.sleep(2)
  print("Analysis of start")
  #包
  library(survival)
  library(survminer)
  #提取目标基因表达矩阵
  e<-Counts[,mutilgene]
  #提取生存时间和事件标签
  met<-c("event","last_followup","age","gender","stage")
  #合并生存时间和时间以及表达矩阵
  dat=cbind(Counts[met],e)
  #构建多因素cox公式
  s = as.formula(paste("Surv(last_followup, event) ~ ",paste(c("age","gender","stage",colnames(e)),collapse = "+")))
  #模型构建
  model <- coxph(s, data = dat )
  #模型信息输出
  print(summary(model)$concordance)
  print(summary(model))
  Sys.sleep(2)
  #模型预测训练集
  fp<-predict(model,newdata = dat)
  #绘制ROC曲线
  outname=paste(out,"/ROC.png",sep="")
  png(filename = outname, width = 925, height = 600)
  
  rocCol=rainbow(3)
  aucText=c()
  roc=survivalROC::survivalROC(Stime = dat$last_followup,status = dat$event,
                               marker = fp,method = "KM",predict.time=1*365)
  print(plot(roc$FP,roc$TP,type="l",xlim=c(0,1),ylim=c(0,1),col=rocCol[1],
       xlab="False positive rate",ylab="True positive rate",lwd=2,cex.main=1.3,
       cex.lab=1.2,cex.axis=1.2,font=1.2))
  aucText=c(aucText,paste0("1 years","(AUC =",sprintf("%.3f",roc$AUC),")"))
  print(abline(0,1))
  
  roc=survivalROC::survivalROC(Stime = dat$last_followup,status = dat$event,
                               marker = fp,predict.time = 3*365,method = "KM")
  aucText=c(aucText,paste0("3 years","(AUC =",sprintf("%.3f",roc$AUC),")"))
  print(lines(roc$FP,roc$TP,type = 'l',xlim=c(0,1),ylim=c(0,1),col=rocCol[2],lwd=2))
  
  roc=survivalROC::survivalROC(Stime = dat$last_followup,status = dat$event,
                               marker = fp,predict.time = 5*365,method = "KM")
  aucText=c(aucText,paste0("5 years","(AUC =",sprintf("%.3f",roc$AUC),")"))
  print(lines(roc$FP,roc$TP,type = 'l',xlim=c(0,1),ylim=c(0,1),col=rocCol[3],lwd=2))
  print(legend("bottomright",aucText,lwd=2,bty="n",col = rocCol))
  while (!is.null(dev.list()))  dev.off()
}
out<-"G:/湘雅/陆君5/00-原始数据/temp2"
multiCox(mutilgene,Counts,out)
















