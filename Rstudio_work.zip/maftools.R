options(stringsAsFactors = F) 
library(maftools)
library(dplyr)
project='TCGA_LUAD'
laml = read.maf(maf = 'G:/湘雅/突变/new/meger_oncotated_raw_call.maf.txt',
                gisticAllLesionsFile = 'G:/湘雅/突变/SNV/raw_seqment/gdac.broadinstitute.org_LUAD.Merge_snp__genome_wide_snp_6__broad_mit_edu__Level_3__segmented_scna_hg19__seg.Level_3.2016012800.0.0/all_lesions.conf_90.txt',
                gisticAmpGenesFile = 'G:/湘雅/突变/SNV/raw_seqment/gdac.broadinstitute.org_LUAD.Merge_snp__genome_wide_snp_6__broad_mit_edu__Level_3__segmented_scna_hg19__seg.Level_3.2016012800.0.0/amp_genes.conf_90.txt',
                gisticDelGenesFile = 'G:/湘雅/突变/SNV/raw_seqment/gdac.broadinstitute.org_LUAD.Merge_snp__genome_wide_snp_6__broad_mit_edu__Level_3__segmented_scna_hg19__seg.Level_3.2016012800.0.0/del_genes.conf_90.txt',
                gisticScoresFile = 'G:/湘雅/突变/SNV/raw_seqment/gdac.broadinstitute.org_LUAD.Merge_snp__genome_wide_snp_6__broad_mit_edu__Level_3__segmented_scna_hg19__seg.Level_3.2016012800.0.0/scores.gistic',isTCGA = TRUE,
                verbose = FALSE)
maf_df = laml@data
save(lam_target,maf_tg_df,file = "maf.Rdata")
#有多少病人
length(unique(maf_df$Tumor_Sample_Barcode))
#有多少突变信息
length(unique(maf_df$Hugo_Symbol))
getSampleSummary(laml) 
getGeneSummary(laml) 
getFields(laml)  
plotmafSummary(maf = laml, rmOutlier = TRUE,showBarcodes = FALSE,
               addStat = 'median', dashboard = TRUE, titvRaw = FALSE)
oncoplot(maf = laml, top = 80, fontSize = 0.5,bgCol = '#ffffff')
laml.titv = titv(maf = laml, plot = FALSE, useSyn = TRUE)
plotTiTv(res = laml.titv)
