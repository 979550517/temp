DX<-read.table(file = "G:/湘雅/陆/a/gene_METABOLISM_uniq.txt",sep="\t")
DE<-data.frame(id=read.table(file = "G:/湘雅/陆/a/DE_down_gene.txt",sep="\t")[,1])
gene<-data.frame(gene_id=intersect(DX$V1,DE$id))
write.table(gene,file = "G:/湘雅/陆/a/下调代谢基因.txt",sep="\t",col.names=T,row.names=F,quote=F)


tcga<-read.table(file = "G:/湘雅/陆/a/FPKM_merge_matrix.xls",sep="\t",header=T)
tcga_out<-cbind(tcga[,1:11],tcga[,intersect(gene$gene_id,colnames(tcga))])
geo<-read.table(file = "G:/湘雅/陆/a/merge_GSE157010.xls",sep="\t",header=T,check.names = FALSE)
geo_out<-cbind(geo[,1:6],geo[,intersect(gene$gene_id,colnames(geo))])
gene<-intersect(colnames(tcga_out),colnames(geo_out))[4:length(gene)]
tcga<-cbind(tcga_out[,1:11],tcga_out[,intersect(gene,colnames(tcga_out))])
geo<-cbind(geo_out[,1:6],geo_out[,intersect(gene,colnames(geo_out))])
write.table(geo,file = "G:/湘雅/陆/a/geoXtcga_geo.txt",sep="\t",col.names=T,row.names=F,quote=F)
write.table(tcga,file = "G:/湘雅/陆/a/geoXtcga_geo_tcga.txt",sep="\t",col.names=T,row.names=F,quote=F)

library(sva)
merge<-t(rbind(tcga[,12:ncol(tcga)],geo[,7:ncol(geo)]))
bathtype=c(rep(1,nrow(tcga)),rep(2,nrow(geo)))
outTab<-ComBat(merge,bathtype,par.prior = T)

tcga_out<-t(outTab[,1:327])
geo_out<-t(outTab[,328:ncol(outTab)])
tcga_out<-cbind(tcga[,1:11],tcga_out)
geo_out<-cbind(geo[,1:6],geo_out)
write.table(geo_out,file = "G:/湘雅/陆/a/标准化geo.xls",sep="\t",col.names=T,row.names=F,quote=F)
write.table(tcga_out,file = "G:/湘雅/陆/a/标准化tcga_geo_tcga.xls",sep="\t",col.names=T,row.names=F,quote=F)

####avereps_limma package
library(survival)
library(survminer)
library(tidyverse)
list = colnames(tcga_out)[12:ncol(tcga_out)]
merge_matrix<-tcga_out
survival<-function(list2,SUR = data_frame()){
  for (var2 in list2) {
    s=as.formula(paste("Surv(last_followup, event) ~ ",var2))
    res.cox2 <- coxph(s,data = merge_matrix)
    #res.cox2 <- coxph(Surv(last_followup, event) ~ var2, data = merge_matrix)
    summary2<-summary(res.cox2)
    p.value2 <- signif(summary2$wald["pvalue"], digits=2)
    HR2 <-signif(summary2$coef[2], digits=4)
    HR2.confint.lower <- signif(summary2$conf.int[,"lower .95"],digits=4)
    HR2.confint.upper <- signif(summary2$conf.int[,"upper .95"],digits=4)
    HR3 <- paste0(HR2, "(", HR2.confint.lower, "~", HR2.confint.upper, ")")
    HR2 <- c(p.value2,HR3,HR2,HR2.confint.lower,HR2.confint.upper)
    names(HR2)<-c("p.value "," HR (95% lower for upper)","HR","95%lower","95%upper")
    temp2 <- as.data.frame(HR2,check.names =FALSE)
    colnames(temp2)<-var2
    temp2 <- t(temp2)
    SUR<-rbind(SUR,temp2)
  }
  return(SUR)
}
cox_result<-survival(list)
write.table(cox_result,file = "G:/湘雅/陆/a/单因素cox分析结果.xls",sep="\t",col.names=T,row.names=T,quote=F)

forest_gene <- dplyr::filter(cox_result,cox_result$`p.value `< 0.05)

library(forestplot)
forest_gene$HR<-as.numeric(forest_gene$HR)
forest_gene$`95%lower`<-as.numeric(forest_gene$`95%lower`)
forest_gene$`95%upper`<-as.numeric(forest_gene$`95%upper`)
forest_gene<-rbind(colnames(forest_gene),forest_gene)
forest_gene2<-forest_gene
forest_gene2<-cbind(rownames(forest_gene2),forest_gene2)
forest_gene2[1,1]<-"gene"
forest_gene<-forest_gene[-1,]
forest_gene$HR<-ifelse(forest_gene$HR>3,3,print(forest_gene$HR))
forest_gene$`95%upper`<-ifelse(forest_gene$`95%upper`>3,3,print(forest_gene$`95%upper`))
# 读入数据的时候一定要把header设置成FALSE，确保第一行不被当作列名称。
forestplot(labeltext = as.matrix(forest_gene2[,1:3]),
           #设置用于文本展示的列，此处我们用数据的前四列作为文本，在图中展示
           mean = c(NA,forest_gene$HR), #设置均值
           lower = c(NA,forest_gene$`95%lower`), #设置均值的lowlimits限
           upper = c(NA,forest_gene$`95%upper`), #设置均值的uplimits限
           is.summary=c(T,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F,F),
           #该参数接受一个逻辑向量，用于定义数据中每一行是否是汇总值，若是，则在对应位置设置为TRUE，若否，则设置为FALSE；设置为TRUE的行则以粗体出现
           zero = 1, #设置参照值，此处我们展示的是HR值，故参照值是1，而不是0
           boxsize = 0.4, #设置点估计的方形大小
           lineheight = unit(16,'mm'),#设置图形中的行距
           colgap = unit(8,'mm'),#设置图形中的列间距
           lwd.zero = 2,#设置参考线的粗细
           lwd.ci = 2,#设置区间估计线的粗细
           col=fpColors(box='#458B00',summary="#8B008B",lines = 'black',zero = '#7AC5CD'),
           #使用fpColors()函数定义图形元素的颜色，从左至右分别对应点估计方形，汇总值，区间估计线，参考线
           xlab="The estimates",#设置x轴标签
           lwd.xaxis=2,#设置X轴线的粗细
           lty.ci = "solid",
           title="forestplot (If the value is greater than, it defaults to 3)",
           graph.pos = 4)#设置森林图的位置，此处设置为4，则出现在第四列

gene<-rownames(forest_gene)
write.table(geo_cox,file = "G:/湘雅/陆/a/GEO_cox基因及临床矩阵.xls",sep="\t",col.names=T,row.names=F,quote=F)
write.table(tcga_cox,file = "G:/湘雅/陆/a/TCGA_cox基因及临床矩阵.xls",sep="\t",col.names=T,row.names=F,quote=F)


library(glmnet)
library(survival)
geo<-read.table(file = "G:/湘雅/陆/a/6-21个基因lasso模型/GEO_cox基因及临床矩阵.xls",header=T,sep="\t",check.names=F)
tcga<-read.table(file = "G:/湘雅/陆/a/6-21个基因lasso模型/TCGA_cox基因及临床矩阵.xls",header=T,sep="\t",check.names=F)
#gene<-c("PTGES","CPS1","UGT2B17","LDHC")
gene<-c("PTGES","CPS1","UGT2B28")
tcga_cox<-cbind(tcga[,1:11],tcga[,gene])
geo_cox<-cbind(geo[,1:6],geo[,gene])
x=as.matrix(tcga_cox[,12:ncol(tcga_cox)])
y=data.matrix(Surv(tcga_cox$last_followup,tcga_cox$event))
fit=glmnet::glmnet(x,y,family = "cox",maxit = 1000)
cvfit=glmnet::cv.glmnet(x,y,family = "cox",maxit = 1000)
coef=coef(fit,s=cvfit$lambda.min)
actCoef<-coef[,1]  ###向量，列表
lassoGene=row.names(coef)
geneCoef=cbind(Gene=lassoGene,Coef=actCoef)
trainFinalGeneExp=tcga_cox[,lassoGene]
myfun<- function(x) {
  crossprod(as.numeric(x),actCoef)
}
trainScore=apply(trainFinalGeneExp,1,myfun)
outCol=c("ID","V1","last_followup","event",lassoGene)
risk<-as.vector(ifelse(trainScore>median(trainScore),"high","low"))
outTab=cbind(tcga_cox[,outCol],riskScore=as.vector(trainScore),risk)

tcgaRisk<-outTab
diff=survdiff(Surv(last_followup,event)~risk,data = tcgaRisk)
pValue=1-pchisq(diff$chisq,df=1)
pValue=signif(pValue,4)
pValue=format(pValue,scientific=TRUE)
fit<- survfit(Surv(last_followup,event)~risk,data = tcgaRisk)
#library('survival')
#library('survminer')
ggsurvplot(fit,
           data = tcgaRisk,
           #surv.median.line = "hv",
           pval = paste("p=",pValue),
           pval.size = 6,
           risk.table = TRUE,
           legend.labs=c("High risk","Low risk"),
           legend.title='Risk',
           xlab="Time(day)",
           break.time.by=500,
           risk.table.title="",
           risk.table.height=.25,
           conf.int = F,
           ncensor.plot=TRUE,
           palette=c("#E7B800","#2E9FDF"),
           ggtheme = theme_light())

write.table(geneCoef,file = 'G:/湘雅/陆/a/geneCoef.txt',
            sep='\t',quote=FALSE,row.names = FALSE,col.names = TRUE)
write.table(outTab,file = 'G:/湘雅/陆/a/tcgaRisk.xls',
            sep='\t',quote=FALSE,row.names = FALSE,col.names = TRUE)

####pheatmap
library(tidyverse)
rt<-tcgaRisk
rt <- rt[!duplicated(rt$V1),]
rownames(rt)<-rt$V1
rt<-rt[order(rt$risk),]
rt2<-rt[,5:9]
rt2<-log2(t(rt2)+1)
annotation<-data_frame(type=rt$risk)
rownames(annotation)<-rownames(rt)
annotation<-as.data.frame(annotation)
library(pheatmap)
pheatmap::pheatmap(rt2,annotation = annotation,cluster_cols = FALSE,
                   fontsize_row = 11,show_colnames = F,fontsize_col = 3,
                   color = colorRampPalette(c("green","black","red"))(50))


testFinalGeneExp=geo_cox[,lassoGene]
testScore=apply(testFinalGeneExp,1,myfun)
outCol=c("sample","last_followup","event",lassoGene)
risk<-as.vector(ifelse(testScore>median(trainScore),"high","low"))
outTab=cbind(geo_cox[,outCol],riskScore=as.vector(testScore),risk)


geoRisk<-outTab
diff=survdiff(Surv(last_followup,event)~risk,data = geoRisk)
pValue=1-pchisq(diff$chisq,df=1)
pValue=signif(pValue,4)
pValue=format(pValue,scientific=TRUE)
fit<- survfit(Surv(last_followup,event)~risk,data = geoRisk)
ggsurvplot(fit,
           data = geoRisk,
           surv.median.line = "hv",
           pval = paste("p=",pValue),
           pval.size = 6,
           risk.table = TRUE,
           legend.labs=c("High risk","Low risk"),
           legend.title='Risk',
           xlab="Time(day)",
           break.time.by=500,
           risk.table.title="",
           risk.table.height=.25,
           conf.int = T,
           ncensor.plot=TRUE,
           palette=c("#E7B800","#2E9FDF"),
           ggtheme = theme_light())

write.table(outTab,file = 'G:/湘雅/陆/a/geoRisk.xls',
            sep='\t',quote=FALSE,row.names = FALSE,col.names = TRUE)