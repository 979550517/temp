#差异分析
##TCGA-Counts矩阵ensenble_id转化为symbol_id
'''
counts<-read.table(file = "G:/湘雅/陆君3/0_TCGA数据/raw_counts_matrix.xls",
                 sep="\t",header=T,check.name=F)
'''
###包：
'''
library(tidyverse)
library(org.Hs.eg.db)
library(clusterProfiler)
'''
counts_symbol<-bitr(counts$id,
                    fromType = 'ENSEMBL',
                    toType = 'SYMBOL',
                    OrgDb = org.Hs.eg.db) %>%
  left_join(counts,by = c('ENSEMBL'='id')) %>%
  distinct(SYMBOL,.keep_all = TRUE)
counts_symbol<-counts_symbol[,-1]
###symbol_id存储位置
'''
write.table(counts_symbol,file = "G:/湘雅/陆君3/0_TCGA数据/symbol_Counts_matrix.xls",
            sep = "\t",col.names = T,quote = F,row.names = F)
'''
##提取差异分析基因中的膜蛋白基因
###代谢基因路径：G:/湘雅/陆君3/01_膜蛋白基因/膜蛋白基因.txt
###DESeq2路径：G:湘雅/陆君3/02_差异分析/DESeq2/symbol_Counts_matrix.xls.cancer_vs_normal.DESeq2.DE_results
###edgeR路径：G:/湘雅/陆君3/02_差异分析/edgeR/symbol_Counts_matrix.xls.cancer_vs_normal.edgeR.DE_results
###limma路径：G:/湘雅/陆君3/02_差异分析/voom/symbol_Counts_matrix.xls.cancer_vs_normal.voom.DE_results
'''
deseq<-read.table(file = "G:/湘雅/陆君3/02_差异分析/DESeq2/symbol_Counts_matrix.xls.cancer_vs_normal.DESeq2.DE_results",
                  sep="\t",header = T,check.names = F,row.names = 1)
edger<-read.table(file = "G:/湘雅/陆君3/02_差异分析/edgeR/symbol_Counts_matrix.xls.cancer_vs_normal.edgeR.DE_results",
                  sep="\t",header = T,check.names = F,row.names = 1)
limma<-read.table(file = "G:/湘雅/陆君3/02_差异分析/voom/symbol_Counts_matrix.xls.cancer_vs_normal.voom.DE_results",
                  sep="\t",header = T,check.names = F,row.names = 1)
MPGene<-read.table(file = "G:/湘雅/陆君3/01_膜蛋白基因/膜蛋白基因.txt",
                           header = F,sep="\t")
'''
COMOGene<-intersect(rownames(deseq),MPGene$V1)
MPdeseq<-deseq[COMOGene,]

edgerCOMOGene<-intersect(rownames(edger),MPGene$V1)
MPedger<-edger[edgerCOMOGene,]

limmaCOMOGene<-intersect(rownames(limma),MPGene$V1)
MPlimma<-limma[limmaCOMOGene,]
###膜蛋白基因差异分析结果路径：G:/湘雅/陆君3/02_差异分析
'''
write.table(MPdeseq,file = "G:/湘雅/陆君3/02_差异分析/膜蛋白差异基因/DEseq_膜蛋白基因结果.xls",
            sep = "\t",quote = F,row.names = T,col.names = T)
write.table(MPedger,file = "G:/湘雅/陆君3/02_差异分析/膜蛋白差异基因/edgeR_膜蛋白基因结果.xls",
            sep = "\t",quote = F,row.names = T,col.names = T)
write.table(MPlimma,file = "G:/湘雅/陆君3/02_差异分析/膜蛋白差异基因/limma_膜蛋白基因结果.xls",
            sep = "\t",quote = F,row.names = T,col.names = T)
'''
###代谢基因火山图
###文件路径：G:/湘雅/陆君3/02_差异分析
'''
MP_deseq<-read.table(file = "G:/湘雅/陆君3/02_差异分析/膜蛋白差异基因/DEseq_膜蛋白基因结果.xls",
            sep = "\t",header = T,row.names = 1,check.names = F)
MP_edger<-read.table(file = "G:/湘雅/陆君3/02_差异分析/膜蛋白差异基因/edgeR_膜蛋白基因结果.xls",
                             sep = "\t",header = T,row.names = 1,check.names = F)
MP_limma<-read.table(file = "G:/湘雅/陆君3/02_差异分析/膜蛋白差异基因/limma_膜蛋白基因结果.xls",
                             sep = "\t",header = T,row.names = 1,check.names = F)
'''
###包
'''
library(EnhancedVolcano)
'''
EnhancedVolcano(MP_deseq,lab = rownames(MP_deseq),x = 'log2FoldChange',y = 'padj',
                xlab = 'DEseq2',ylab = NULL,pCutoff = 0.05,FCcutoff = 1,selectLab=F)
EnhancedVolcano(MP_edger,lab = rownames(MP_edger),x = 'logFC',y = 'FDR',
                xlab = 'EdgeR',ylab = NULL,pCutoff = 0.05,FCcutoff = 1,selectLab=F)
EnhancedVolcano(MP_limma,lab = rownames(MP_limma),x = 'logFC',y = 'FDR',
                xlab = 'Limma',ylab = NULL,pCutoff = 0.05,FCcutoff = 1,selectLab=F)
##提取上下调基因
###文件路径：G:/湘雅/陆君3/02_差异分析
'''
MP_deseq<-read.table(file = "G:/湘雅/陆君3/02_差异分析/膜蛋白差异基因/DEseq_膜蛋白基因结果.xls",
            sep = "\t",header = T,row.names = 1,check.names = F)
MP_edger<-read.table(file = "G:/湘雅/陆君3/02_差异分析/膜蛋白差异基因/edgeR_膜蛋白基因结果.xls",
                             sep = "\t",header = T,row.names = 1,check.names = F)
MP_limma<-read.table(file = "G:/湘雅/陆君3/02_差异分析/膜蛋白差异基因/limma_膜蛋白基因结果.xls",
                             sep = "\t",header = T,row.names = 1,check.names = F)
'''
up_deseq<- dplyr::filter(MP_deseq,log2FoldChange > 1 & padj < 0.05)
up_deseq<-cbind(up_deseq,change=rep("up",length(up_deseq$sampleA)))
down_deseq<- dplyr::filter(MP_deseq,log2FoldChange < -1 & padj < 0.05)
down_deseq<-cbind(down_deseq,change=rep("down",length(down_deseq$sampleA)))
deseq_change<-rbind(down_deseq,up_deseq)

up_edger<- dplyr::filter(MP_edger,logFC > 1 & FDR < 0.05)
up_edger<-cbind(up_edger,change=rep("up",length(up_edger$sampleA)))
down_edger<- dplyr::filter(MP_edger,logFC < -1 & FDR < 0.05)
down_edger<-cbind(down_edger,change=rep("down",length(down_edger$sampleA)))
edger_change<-rbind(down_edger,up_edger)

up_limma<- dplyr::filter(MP_limma,logFC > 1 & FDR < 0.05)
up_limma<-cbind(up_limma,change=rep("up",length(up_limma$sampleA)))
down_limma<- dplyr::filter(MP_limma,logFC < -1 & FDR < 0.05)
down_limma<-cbind(down_limma,change=rep("down",length(down_limma$sampleA)))
limma_change<-rbind(down_limma,up_limma)
###上下调基因存储路径：G:/湘雅/陆君3/02_差异分析/差异基因
'''
write.table(up_deseq,file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/DEseq2/DEseq2上调基因.xls",
            sep = "\t",quote = F,col.names = T,row.names = T)
write.table(down_deseq,file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/DEseq2/DEseq2下调基因.xls",
            sep = "\t",quote = F,col.names = T,row.names = T)
write.table(deseq_change,file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/DEseq2/DEseq2上下调基因.xls",
            sep = "\t",quote = F,col.names = T,row.names = T)

write.table(up_edger,file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/EdgeR/EdgeR上调基因.xls",
            sep = "\t",quote = F,col.names = T,row.names = T)
write.table(down_edger,file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/EdgeR/EdgeR下调基因.xls",
            sep = "\t",quote = F,col.names = T,row.names = T)
write.table(edger_change,file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/EdgeR/EdgeR上下调基因.xls",
            sep = "\t",quote = F,col.names = T,row.names = T)

write.table(up_limma,file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/Limma/Limma上调基因.xls",
            sep = "\t",quote = F,col.names = T,row.names = T)
write.table(down_limma,file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/Limma/Limma下调基因.xls",
            sep = "\t",quote = F,col.names = T,row.names = T)
write.table(limma_change,file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/Limma/Limma上下调基因.xls",
            sep = "\t",quote = F,col.names = T,row.names = T)
'''
##绘制上下调基因热图
###上下调基因文件位置：G:/湘雅/陆君3/02_差异分析/上下调代谢差异基因
###Counts表达文件位置：G:/湘雅/陆君3/0_TCGA数据/symbol_Counts_matrix.xls
###样本信息位置：G:/湘雅/陆君3/0_TCGA数据/sample_information.txt
'''
deseq_change<-read.table(file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/DEseq2/DEseq2上下调基因.xls",
                         sep="\t",header=T,row.names=1,check.name=F)
edger_change<-read.table(file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/EdgeR/EdgeR上下调基因.xls",
                         sep="\t",header=T,row.names=1,check.name=F)
limma_change<-read.table(file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/Limma/Limma上下调基因.xls",
                         sep="\t",header=T,row.names=1,check.name=F)
counts<-read.table(file = "G:/湘雅/陆君3/0_TCGA数据/symbol_Counts_matrix.xls",
                 sep="\t",header=T,row.names=1,check.name=F)
sample_info<-read.table(file = "G:/湘雅/陆君3/0_TCGA数据/sample_information.txt",
                 sep="\t",header=F,check.name=F)
'''
###包：
'''
library(pheatmap)
'''
sample_info<-data.frame(t(sample_info))
colnames(sample_info)<-sample_info[2,]
sample_info<-sample_info[-2,]
counts<-rbind(sample_info,counts)
counts<-counts[,order(counts[1,])]
ann<-t(counts[1,])
ann<-as.data.frame(ann)
colnames(ann)<-"tissue"
deseq_gene<-rownames(deseq_change)
deseq_counts<-counts[c("V1",deseq_gene),]
deseq_counts=apply(deseq_counts[2:nrow(deseq_counts),],2,as.numeric)
row.names(deseq_counts)<-deseq_gene
deseq_counts<-as.data.frame(deseq_counts)

edger_gene<-rownames(edger_change)
edger_counts<-counts[c("V1",edger_gene),]
edger_counts=apply(edger_counts[2:nrow(edger_counts),],2,as.numeric)
row.names(edger_counts)<-edger_gene
edger_counts<-as.data.frame(edger_counts)

limma_gene<-rownames(limma_change)
limma_counts<-counts[c("V1",limma_gene),]
limma_counts=apply(limma_counts[2:nrow(limma_counts),],2,as.numeric)
row.names(limma_counts)<-limma_gene
limma_counts<-as.data.frame(limma_counts)

pheatmap::pheatmap(log10(deseq_counts+1),annotation_col = ann,cluster_cols = FALSE,
                   show_colnames = F,show_rownames = F,
                   main	="DEseq2")
pheatmap::pheatmap(log10(edger_counts+1),annotation_col = ann,cluster_cols = FALSE,
                   show_colnames = F,show_rownames = F,
                   main="EdgeR")
pheatmap::pheatmap(log10(limma_counts+1),annotation_col = ann,cluster_cols = FALSE,
                   show_colnames = F,show_rownames = F,
                   main="Limma")
##提取上下调共有基因及绘制上调基因和下调基因的韦恩图
###上下调基因位置
'''
deseq_up<-read.table(file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/DEseq2/DEseq2上调基因.xls",
                         sep="\t",header=T,row.names=1,check.name=F)
edger_up<-read.table(file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/EdgeR/EdgeR上调基因.xls",
                         sep="\t",header=T,row.names=1,check.name=F)
limma_up<-read.table(file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/Limma/Limma上调基因.xls",
                         sep="\t",header=T,row.names=1,check.name=F)
deseq_down<-read.table(file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/DEseq2/DEseq2下调基因.xls",
                         sep="\t",header=T,row.names=1,check.name=F)
edger_down<-read.table(file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/EdgeR/EdgeR下调基因.xls",
                         sep="\t",header=T,row.names=1,check.name=F)
limma_down<-read.table(file = "G:/湘雅/陆君3/02_差异分析/上下调膜蛋白差异基因/Limma/Limma下调基因.xls",
                         sep="\t",header=T,row.names=1,check.name=F)
'''
###包：
'''
install.packages("ggvenn")
library(ggvenn)
'''
co_upGene<-data.frame(gene=intersect(intersect(rownames(deseq_up),rownames(edger_up)),rownames(limma_up)))
co_downGene<-data.frame(gene=intersect(intersect(rownames(deseq_down),rownames(edger_down)),rownames(limma_down)))
up_gene<-list(DEseq2_UP=rownames(deseq_up),EdgeR_UP=rownames(edger_up),Limma_UP=rownames(limma_up))
ggvenn(up_gene,c("DEseq2_UP","EdgeR_UP","Limma_UP"),fill_color = c("LightPink","Gold","LightGreen"),
       fill_alpha = 0.5,stroke_color = "white",stroke_alpha = 1,
       set_name_color = c("LightPink","Gold","LightGreen"),show_percentage = F,
       text_size = 5)
down_gene<-list(DEseq2_DOWN=rownames(deseq_down),EdgeR_DOWN=rownames(edger_down),Limma_DOWN=rownames(limma_down))
ggvenn(down_gene,c("DEseq2_DOWN","EdgeR_DOWN","Limma_DOWN"),fill_color = c("LightPink","Gold","LightGreen"),
       fill_alpha = 0.5,stroke_color = "white",stroke_alpha = 1,
       set_name_color = c("LightPink","Gold","LightGreen"),show_percentage = F,
       text_size = 5)
###共有上下调基因存储位置
'''
write.table(co_upGene,file = "G:/湘雅/陆君3/02_差异分析/共有上调基因.xls",
            sep = "\t",quote = F,col.names = T,row.names = F)
write.table(co_downGene,file = "G:/湘雅/陆君3/02_差异分析/共有下调基因.xls",
            sep = "\t",quote = F,col.names = T,row.names = F)
'''
#单基因生存分析
##提取基因样本矩阵
###提取原始Counts矩阵中共有上调基因
'''
raw_counts<-read.table(file = "G:/湘雅/陆君3/0_TCGA数据/symbol_Counts_matrix.xls",
                     sep = "\t",header = T,row.names = 1,check.names = F)
co_upGene<-read.table(file = "G:/湘雅/陆君3/02_差异分析/共有上调基因.xls",
                      sep = "\t",header = T,check.names = F)
'''
Counts<-t(raw_counts[co_upGene$gene,])
###无临床信息目标基因矩阵存储位置
'''
write.table(Counts,file = "G:/湘雅/陆君3/03_单基因生存分析/无样本信息上调基因Counts矩阵.xls",
            sep = "\t",quote=F,col.names=T,row.names=T)
'''
###合并样本信息并筛选样本
###目标基因Counts矩阵及临床信息位置
###文件需要Excel处理
'''
Counts<-read.table(file = "G:/湘雅/陆君3/03_单基因生存分析/无样本信息上调基因Counts矩阵.xls",
                 sep = "\t",header = T,check.names = F)
clinical<-read.table(file = "G:/湘雅/陆君3/0_TCGA数据/raw_meta.xls",
                     sep = "\t",header = T,check.names = F)
'''
###包
'''
library(tidyverse)
'''
merge_Counts<-left_join(Counts,clinical,by = c('patient_id'='ID'))%>%
  distinct(sample,.keep_all = TRUE)
merge_Counts <- dplyr::filter(merge_Counts,last_followup > 0)
###含有临床信息目标样本FPKM矩阵存储位置
'''
write.table(merge_Counts,file = "G:/湘雅/陆君3/03_单基因生存分析/目标基因Counts矩阵_含临床信息.xls",
            sep = "\t",quote=F,col.names=T,row.names=F)
'''
###批量单基因生存分析
###含有临床信息的矩阵文件位置
'''
FPKM<-read.table(file = "G:/湘雅/陆君3/03_单基因生存分析/目标基因Counts矩阵_含临床信息.xls",
                 sep = "\t",header = T,row.names = 1,check.names = F)
'''
###包
'''
library('survival')
library('survminer')
'''
singleSuvival<-function(x){
  outCol=c("patient_id","last_followup","event",x)
  colName<-colnames(FPKM)
  index=as.numeric(which(colName==x))
  Change<-as.vector(ifelse(FPKM[,index]>median(FPKM[,index]),"high","low"))
  outTab=cbind(rownames(FPKM),FPKM[,outCol],HROL=Change)
  diff=survdiff(Surv(last_followup,event)~HROL,data = outTab)
  pValue=1-pchisq(diff$chisq,df=1)
  pValue=signif(pValue,4)
  if(pValue<0.05){
    fit<- survfit(Surv(last_followup,event)~HROL,data = outTab)
    outname=paste("G:/湘雅/陆君3/03_单基因生存分析/生存分析图/",x,".png",sep="")
    png(filename = outname, width = 925, height = 600)
    print(ggsurvplot(fit,
                     data = outTab,
                     surv.median.line = "hv",
                     pval = paste("p=",pValue),
                     pval.size = 6,
                     risk.table = TRUE,
                     legend.labs=c("High Express","Low Express"),
                     legend.title='Express',
                     xlab="Time(day)",
                     break.time.by=500,
                     risk.table.title="",
                     risk.table.height=.25,
                     conf.int = F,
                     ncensor.plot=TRUE,
                     palette=c("#E7B800","#2E9FDF"),
                     ggtheme = theme_light()))
  }
  else{
    print(paste(x,pValue,sep=" "))
  }
  #Sys.sleep(1)
  while (!is.null(dev.list()))  dev.off()
}
gene<-colnames(FPKM)
gene<-data.frame(gene[2:316])
apply(gene,1,singleSuvival)


###风险曲线
###含有临床信息的矩阵文件位置
'''
FPKM<-read.table(file = "G:/湘雅/陆君3/03_单基因生存分析/目标基因Counts矩阵_含临床信息.xls",
                 sep = "\t",header = T,row.names = 1,check.names = F)
gene<-c("FCRL5","SLC35F2","CLCN1","SLC2A5","ITGA11","GPR156","SLC6A17","SYNGR4","BEST3","CNTNAP4","PCDH8","KCNU1")
cli<-read.table("G:/湘雅/陆君3/03_单基因生存分析/meta_format.xls",
sep = "\t",check.names = F,header = T)
'''
FPKM$last_followup<-(FPKM$last_followup/365)
plotQX<-function(FPKM,gene,cli){
  library(survival)
  library(glmnet) 
  library(survminer)
  library(tidyverse)
  library(survivalROC)
  library(tidyverse)
  x=log2(as.matrix(FPKM[,gene])+1)
  y=data.matrix(Surv(FPKM$last_followup,FPKM$event))
  fit=glmnet::glmnet(x,y,family = "cox",nlambda=1000)
  png(filename = "G:/湘雅/陆君3/03_单基因生存分析/风险曲线/tempLasso1.png")
  print(plot(fit, xvar = "lambda", label = TRUE))
  while (!is.null(dev.list()))  dev.off()
  cvfit=glmnet::cv.glmnet(x,y,family = "cox",nlambda=1000)
  png(filename = "G:/湘雅/陆君3/03_单基因生存分析/风险曲线/tempLasso2.png")
  print(plot(cvfit))
  print(abline(v = log(c(cvfit$lambda.min,cvfit$lambda.1se)),lty="dashed"))
  while (!is.null(dev.list()))  dev.off()
  coef=coef(fit,s=cvfit$lambda.min)
  Sys.sleep(1)
  actCoef<-coef[,1]  ###向量，列表
  #####################
  print(actCoef)
  #####################
  lassoGene=row.names(coef)
  geneCoef=cbind(Gene=lassoGene,Coef=actCoef)
  trainFinalGeneExp=FPKM[,lassoGene]
  myfun<- function(x) {
    crossprod(as.numeric(x),actCoef)
  }
  trainScore=apply(trainFinalGeneExp,1,myfun)
  outCol=c("patient_id","last_followup","event",lassoGene)
  risk<-as.vector(ifelse(trainScore>median(trainScore),"high","low"))
  outTab=cbind(sample=rownames(FPKM),FPKM[,outCol],riskScore=as.vector(trainScore),risk)
  print(colnames(outTab))
  diff=survdiff(Surv(last_followup,event)~risk,data = outTab)
  pValue=1-pchisq(diff$chisq,df=1)
  pValue=signif(pValue,4)
  pValue=format(pValue,scientific=TRUE)
  fit<- survfit(Surv(last_followup,event)~risk,data = outTab)
  png(filename = "G:/湘雅/陆君3/03_单基因生存分析/风险曲线/temp生存曲线.png")
  print(ggsurvplot(fit,
             data = outTab,
             surv.median.line = "hv",
             pval = paste("p=",pValue),
             pval.size = 6,
             risk.table = TRUE,
             legend.labs=c("High risk","Low risk"),
             legend.title='Risk',
             xlab="Time(year)",
             break.time.by=1,
             risk.table.title="",
             risk.table.height=.25,
             conf.int = F,
             ncensor.plot=TRUE,
             palette=c("#E7B800","#2E9FDF"),
             ggtheme = theme_light()))
  while (!is.null(dev.list()))  dev.off()
  write.table(outTab,file = "G:/湘雅/陆君3/03_单基因生存分析/tempRisk.xls",
              sep = "\t",quote=F,col.names=T,row.names=F)
  ####风险曲线
  fit2<-outTab
  fit2<-fit2[order(fit2$riskScore),]
  riskClass<-fit2[,"risk"]
  lowLength=length(riskClass[riskClass=="low"])
  highLength=length(riskClass[riskClass=="high"])
  line=fit2[,"riskScore"]
  #line[line>0.8]=0.8
  #line[line<0]=0
  png(filename = "G:/湘雅/陆君3/03_单基因生存分析/风险曲线/temp风险曲线.png")
  print(plot(line,type="p",pch=20,xlab="Patients(increasing risk score)",
       ylab = "Risk score",col=c(rep("green",lowLength),rep("red",highLength))))
  print(abline(h=median(fit2$riskScore),v=lowLength,lty=2))
  print(legend("topleft",c("High risk","Low risk"),bty = "n",pch = 19,col = c("red","green"),cex=1.2))
  while (!is.null(dev.list()))  dev.off()
  ###生与死点状图
  color=as.vector(fit2$event)
  color[color==1]="red"
  color[color==0]="green"
  png(filename = "G:/湘雅/陆君3/03_单基因生存分析/风险曲线/temp生与死点状图.png")
  print(plot(fit2$last_followup,pch=19,xlab = "Patients(increasing risk score)"
       ,ylab = "Survival time(year)",col = color))
  print(legend("topleft",c("Dead","Alive"),bty="n",pch = 19,col = c("red","green"),cex = 1.2))
  print(abline(v=lowLength,lty=2))
  while (!is.null(dev.list()))  dev.off()
  ###模型基因热图
  ##################################################
  rt_pheatmap<-fit2[,lassoGene]
  ##################################################
  rt_pheatmap<-log2(rt_pheatmap+1)
  rt_pheatmap<-t(rt_pheatmap)
  annotation<-data.frame(type=fit2[,ncol(fit2)])
  row.names(annotation)<-rownames(fit2)
  png(filename = "G:/湘雅/陆君3/03_单基因生存分析/风险曲线/temp热图.png")
  print(pheatmap::pheatmap(rt_pheatmap,annotation = annotation,cluster_cols = FALSE,
                     fontsize_row = 11,show_colnames = F,fontsize_col = 3,
                     color = colorRampPalette(c("green","black","red"))(50)))
  while (!is.null(dev.list()))  dev.off()
  risk<-read.table("G:/湘雅/陆君3/03_单基因生存分析/tempRisk.xls",
                   header = T,sep = '\t',check.names = F)
  sameSample<-data.frame(intersect(risk$patient_id,cli$ID))
  colnames(sameSample)<-"ID"
  temp <- left_join(sameSample,risk,by=c("ID"="patient_id"))
  rt <- left_join(temp,cli,by=c("ID"="ID"))
  rt2<-cbind(rt[,c(1,2,3,4)],rt[,c(ncol(rt),ncol(rt)-1,ncol(rt)-2,ncol(rt)-3)],rt[,5:(6+length(gene))])
  rocCol=rainbow(ncol(rt2)-3)
  aucText<-c()
  
  par(oma=c(0.5,1,0,1),font.lab = 1.5,font.axis=1.5)
  roc=survivalROC::survivalROC(Stime = rt2$last_followup,status = rt2$event,
                               marker = rt2$riskScore,method = "KM",predict.time=3)
  png(filename = "G:/湘雅/陆君3/03_单基因生存分析/风险曲线/tempROC.png")
  print(plot(roc$FP,roc$TP,type="l",xlim=c(0,1),ylim=c(0,1),col=rocCol[1],
             xlab="False positive rate",ylab="True positive rate",lwd=2,cex.main=1.3,
             cex.lab=1.2,cex.axis=1.2,font=1.2))
  aucText=c(aucText,paste0("risk Score","(AUC =",sprintf("%.3f",roc$AUC),")"))
  print(abline(0,1))
  
  j=1
  for (i in colnames(rt2[,5:(ncol(rt2)-2)])) {
    roc=survivalROC::survivalROC(Stime = rt2$last_followup,status = rt2$event,
                                 marker = rt2[,i],predict.time = 3,method = "KM")
    j=j+1
    aucText=c(aucText,paste0(i,"(AUC =",sprintf("%.3f",roc$AUC),")"))
    print(lines(roc$FP,roc$TP,type = 'l',xlim=c(0,1),ylim=c(0,1),col=rocCol[j],lwd=2))
  }
  print(legend("bottomright",aucText,lwd=2,bty="n",col = rocCol))
  while (!is.null(dev.list()))  dev.off()
}






########################################################
lasso.prob<-predict(cvfit,newx=x,s=cvfit$lambda.min)
re=cbind(y,lasso.prob)
library(timeROC)
lasso.prob<-cbind(sample=rownames(lasso.prob),V1=lasso.prob[,1])
rownames(rt2)<-rt2$sample
id_name<-data.frame(intersect(lasso.prob[,1],rt2$sample))
colnames(id_name)<-"sample"
lasso.prob<-as.data.frame(lasso.prob)
rt3<-left_join(rt2,lasso.prob,by=c("sample"="sample"))
rt3$V1<-as.numeric(rt3$V1)
with(rt3,
     ROC <<- timeROC(T=last_followup,delta = event,marker = V1,cause = 1,
            weighting = "marginal",times = c((3*12*30),(5*12*30)),ROC = TRUE,iid=TRUE))
################event###############################################
library(survival)
library(glmnet) 
library(survminer)
library(tidyverse)
library(survivalROC)
library(tidyverse)
library(ggpubr)
FPKM<-read.table(file = "G:/湘雅/陆君3/03_单基因生存分析/癌样本矩阵含临床信息.xls",
                 sep = "\t",header = T,row.names = 1,check.names = F)
gene<-c("FCRL5","SLC35F2","CLCN1","SLC2A5","ITGA11","GPR156","SLC6A17","SYNGR4","BEST3","CNTNAP4","PCDH8","KCNU1")
cli<-read.table("G:/湘雅/陆君3/03_单基因生存分析/meta_format.xls",sep = "\t",check.names = F,header = T)
FPKM$last_followup<-(FPKM$last_followup/365)
x=log2(as.matrix(FPKM[,gene])+1)
y=FPKM$event
cv_fit<-cv.glmnet(x = x,y = y,nlambda=1000,alpha = 1)
plot(cv_fit)
model_lasso_min<-glmnet(x=x,y=y,alpha=1,lambda = cv_fit$lambda.min)
model_lasso_lse<-glmnet(x=x,y=y,alpha=1,lambda = cv_fit$lambda.1se)
choose_gene_min=rownames(model_lasso_min$beta)[as.numeric(model_lasso_min$beta)!=0]
choose_gene_lse=rownames(model_lasso_lse$beta)[as.numeric(model_lasso_lse$beta)!=0]
model_lasso_lse$beta
model_lasso_min$beta
length(choose_gene_lse)
length(choose_gene_min)
lasso.prob<-predict(cv_fit,newx = x,s=c(cv_fit$lambda.min,cv_fit$lambda.1se))
re<-cbind(y,lasso.prob)
re<-as.data.frame(re)
colnames(re)=c("event","prob_min","prob_lse")
re$event<-as.factor(re$event)
ggboxplot(re,x="event",y="prob_min",color = "event",palette="jco",add = "jitter")+
  scale_y_continuous(limits = c(0,1))+
  stat_compare_means()
ggboxplot(re,x="event",y="prob_lse",color = "event",palette="jco",add = "jitter")+
  scale_y_continuous(limits = c(0,1))+
  stat_compare_means()

sameSample<-data.frame(intersect(FPKM$patient_id,cli$ID))
colnames(sameSample)<-"ID"
FPKM$fp<-as.numeric(lasso.prob[,1])
roc=survivalROC::survivalROC(Stime = FPKM$last_followup,status = FPKM$event,
 marker = FPKM$fp,method = "KM",predict.time=3)
rocCol=rainbow(2)
aucText=c()
plot(roc$FP,roc$TP,type="l",xlim=c(0,1),ylim=c(0,1),col=rocCol[1],
 xlab="False positive rate",ylab="True positive rate",lwd=2,cex.main=1.3,
  cex.lab=1.2,cex.axis=1.2,font=1.2)
aucText=c(aucText,paste0("3 years","(AUC =",sprintf("%.3f",roc$AUC),")"))
abline(0,1)

roc=survivalROC::survivalROC(Stime = FPKM$last_followup,status = FPKM$event,
                             marker = FPKM$fp,predict.time = 5,method = "KM")
aucText=c(aucText,paste0("5years","(AUC =",sprintf("%.3f",roc$AUC),")"))
lines(roc$FP,roc$TP,type = 'l',xlim=c(0,1),ylim=c(0,1),col=rocCol[2],lwd=2)
legend("bottomright",aucText,lwd=2,bty="n",col = rocCol)

ggsurvplot(model_lasso_min,
           data = FPKM,
           surv.median.line = "hv",
           pval = paste("p=",pValue),
           pval.size = 6,
           risk.table = TRUE,
           legend.labs=c("High risk","Low risk"),
           legend.title='Risk',
           xlab="Time(year)",
           break.time.by=1,
           risk.table.title="",
           risk.table.height=.25,
           conf.int = F,
           ncensor.plot=TRUE,
           palette=c("#E7B800","#2E9FDF"),
           ggtheme = theme_light())

with(FPKM,ROC <<- timeROC(T=last_followup,delta = event,marker = fp,cause = 1,weighting = "marginal",times=c(3,5),ROC = TRUE,iid = TRUE))
auc_3<-ROC$AUC[[1]]
auc_5<-ROC$AUC[[2]]

####################
'''
FPKM<-read.table(file = "G:/湘雅/陆君3/03_单基因生存分析/癌样本矩阵含临床信息.xls",
                 sep = "\t",header = T,row.names = 1,check.names = F)
gene<-c("FCRL5","SLC35F2","CLCN1","SLC2A5","ITGA11","GPR156","SLC6A17","SYNGR4","BEST3","CNTNAP4","PCDH8","KCNU1")
cli<-read.table("G:/湘雅/陆君3/03_单基因生存分析/meta_format.xls",
sep = "\t",check.names = F,header = T)
'''
FPKM$last_followup<-(FPKM$last_followup/365)
plotQX<-function(FPKM,gene,cli){
  library(survival)
  library(glmnet) 
  library(survminer)
  library(tidyverse)
  library(survivalROC)
  library(tidyverse)
  x=log2(as.matrix(FPKM[,gene])+1)
  y=FPKM$event
  fit=glmnet::glmnet(x,y,alpha = 1,nlambda=1000)
  png(filename = "G:/湘雅/陆君3/03_单基因生存分析/风险曲线/tempLasso1.png")
  print(plot(fit, xvar = "lambda", label = TRUE))
  while (!is.null(dev.list()))  dev.off()
  cvfit=glmnet::cv.glmnet(x,y,alpha = 1,nlambda=1000)
  model_lasso_min<-glmnet(x=x,y=y,alpha=1,lambda = cvfit$lambda.min)
  png(filename = "G:/湘雅/陆君3/03_单基因生存分析/风险曲线/tempLasso2.png")
  print(plot(cvfit))
  print(abline(v = log(c(cvfit$lambda.min,cvfit$lambda.1se)),lty="dashed"))
  while (!is.null(dev.list()))  dev.off()
  coef=coef(fit,s=model_lasso_min$lambda.min)
  Sys.sleep(1)
  actCoef<-coef[,1]  ###向量，列表
  #####################
  print(actCoef)
  #####################
  lassoGene=rownames(model_lasso_min$beta)[as.numeric(model_lasso_min$beta)!=0]
  actCoef2<-model_lasso_min$beta[as.numeric(model_lasso_min$beta)!=0]
  geneCoef=cbind(Gene=lassoGene,Coef=actCoef)
  trainFinalGeneExp=FPKM[,lassoGene]
  myfun<- function(x) {
    crossprod(as.numeric(x),actCoef)
  }
  trainScore=apply(trainFinalGeneExp,1,myfun)
  outCol=c("patient_id","last_followup","event",lassoGene)
  risk<-as.vector(ifelse(trainScore>median(trainScore),"high","low"))
  outTab=cbind(sample=rownames(FPKM),FPKM[,outCol],riskScore=as.vector(trainScore),risk)
  print(colnames(outTab))
  diff=survdiff(Surv(last_followup,event)~risk,data = outTab)
  pValue=1-pchisq(diff$chisq,df=1)
  pValue=signif(pValue,4)
  pValue=format(pValue,scientific=TRUE)
  fit<- survfit(Surv(last_followup,event)~risk,data = outTab)
  png(filename = "G:/湘雅/陆君3/03_单基因生存分析/风险曲线/temp生存曲线.png")
  print(ggsurvplot(fit,
                   data = outTab,
                   surv.median.line = "hv",
                   pval = paste("p=",pValue),
                   pval.size = 6,
                   risk.table = TRUE,
                   legend.labs=c("High risk","Low risk"),
                   legend.title='Risk',
                   xlab="Time(year)",
                   break.time.by=1,
                   risk.table.title="",
                   risk.table.height=.25,
                   conf.int = F,
                   ncensor.plot=TRUE,
                   palette=c("#E7B800","#2E9FDF"),
                   ggtheme = theme_light()))
  while (!is.null(dev.list()))  dev.off()
  write.table(outTab,file = "G:/湘雅/陆君3/03_单基因生存分析/tempRisk.xls",
              sep = "\t",quote=F,col.names=T,row.names=F)
  ####风险曲线
  fit2<-outTab
  fit2<-fit2[order(fit2$riskScore),]
  riskClass<-fit2[,"risk"]
  lowLength=length(riskClass[riskClass=="low"])
  highLength=length(riskClass[riskClass=="high"])
  line=fit2[,"riskScore"]
  #line[line>0.8]=0.8
  #line[line<0]=0
  png(filename = "G:/湘雅/陆君3/03_单基因生存分析/风险曲线/temp风险曲线.png")
  print(plot(line,type="p",pch=20,xlab="Patients(increasing risk score)",
             ylab = "Risk score",col=c(rep("green",lowLength),rep("red",highLength))))
  print(abline(h=median(fit2$riskScore),v=lowLength,lty=2))
  print(legend("topleft",c("High risk","Low risk"),bty = "n",pch = 19,col = c("red","green"),cex=1.2))
  while (!is.null(dev.list()))  dev.off()
  ###生与死点状图
  color=as.vector(fit2$event)
  color[color==1]="red"
  color[color==0]="green"
  png(filename = "G:/湘雅/陆君3/03_单基因生存分析/风险曲线/temp生与死点状图.png")
  print(plot(fit2$last_followup,pch=19,xlab = "Patients(increasing risk score)"
             ,ylab = "Survival time(year)",col = color))
  print(legend("topleft",c("Dead","Alive"),bty="n",pch = 19,col = c("red","green"),cex = 1.2))
  print(abline(v=lowLength,lty=2))
  while (!is.null(dev.list()))  dev.off()
  ###模型基因热图
  ##################################################
  rt_pheatmap<-fit2[,lassoGene]
  ##################################################
  rt_pheatmap<-log2(rt_pheatmap+1)
  rt_pheatmap<-t(rt_pheatmap)
  annotation<-data.frame(type=fit2[,ncol(fit2)])
  row.names(annotation)<-rownames(fit2)
  png(filename = "G:/湘雅/陆君3/03_单基因生存分析/风险曲线/temp热图.png")
  print(pheatmap::pheatmap(rt_pheatmap,annotation = annotation,cluster_cols = FALSE,
                           fontsize_row = 11,show_colnames = F,fontsize_col = 3,
                           color = colorRampPalette(c("green","black","red"))(50)))
  while (!is.null(dev.list()))  dev.off()
  risk<-read.table("G:/湘雅/陆君3/03_单基因生存分析/tempRisk.xls",
                   header = T,sep = '\t',check.names = F)
  sameSample<-data.frame(intersect(risk$patient_id,cli$ID))
  colnames(sameSample)<-"ID"
  temp <- left_join(sameSample,risk,by=c("ID"="patient_id"))
  rt <- left_join(temp,cli,by=c("ID"="ID"))
  rt2<-cbind(rt[,c(1,2,3,4)],rt[,c(ncol(rt),ncol(rt)-1,ncol(rt)-2,ncol(rt)-3)],rt[,5:(6+length(gene))])
  rocCol=rainbow(ncol(rt2)-3)
  aucText<-c()
  
  par(oma=c(0.5,1,0,1),font.lab = 1.5,font.axis=1.5)
  roc=survivalROC::survivalROC(Stime = rt2$last_followup,status = rt2$event,
                               marker = rt2$riskScore,method = "KM",predict.time=3)
  png(filename = "G:/湘雅/陆君3/03_单基因生存分析/风险曲线/tempROC.png")
  print(plot(roc$FP,roc$TP,type="l",xlim=c(0,1),ylim=c(0,1),col=rocCol[1],
             xlab="False positive rate",ylab="True positive rate",lwd=2,cex.main=1.3,
             cex.lab=1.2,cex.axis=1.2,font=1.2))
  aucText=c(aucText,paste0("risk Score","(AUC =",sprintf("%.3f",roc$AUC),")"))
  print(abline(0,1))
  
  j=1
  for (i in colnames(rt2[,5:(ncol(rt2)-2)])) {
    roc=survivalROC::survivalROC(Stime = rt2$last_followup,status = rt2$event,
                                 marker = rt2[,i],predict.time = 3,method = "KM")
    j=j+1
    aucText=c(aucText,paste0(i,"(AUC =",sprintf("%.3f",roc$AUC),")"))
    print(lines(roc$FP,roc$TP,type = 'l',xlim=c(0,1),ylim=c(0,1),col=rocCol[j],lwd=2))
  }
  print(legend("bottomright",aucText,lwd=2,bty="n",col = rocCol))
  while (!is.null(dev.list()))  dev.off()
}